<?php
// Menghapus session yang telah dibuat
session_start();

function logout() {
    session_destroy();
    header('location: login.php');
    exit;
}

// Cek apakah ada permintaan untuk logout
if (isset($_GET['logout'])) {
    // Tampilkan pesan konfirmasi sebelum logout
    echo "Anda yakin ingin keluar? <a href='?confirm=yes' class='btn yes-btn'>Ya</a> / <a href='?confirm=no' class='btn no-btn'>Tidak</a>";
    exit;
}

// Cek apakah konfirmasi logout sudah dikonfirmasi
if (isset($_GET['confirm'])) {
    if ($_GET['confirm'] === 'yes') {
        logout();
    } else {
        header('location: login.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Logout Confirmation </title>
    <link rel="stylesheet" type="text/css" href="css/logout.css">
     <style>
    body {

      font-family: 'Poppins', sans-serif;
      background-image: url('images/background/nana.jpg');
      height: 100vh;
      background-size: cover;
      background-position: center;
      background-color: rgba(255, 255, 255, 0.9); 
      opacity: 0.9;

    }
        .card {
            background-color: rgba(255, 255, 255, 0.95); 
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 400px;
            height: 150px;
            text-align: center;
        }
        .btn-container {
            margin-top: 20px;
            display: flex;
    		justify-content: center; 
    		align-items: center;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            cursor: pointer;
            width: 100px;
            height: 20px;
            margin-top: 10px; 
            
        }

    
  </style>
</head>
<body>
    <div class="card">
        <h2>Terima Kasih Telah Berkunjung</h2>
        <p>Anda yakin ingin keluar?</p>
        <div class="btn-container">
            <a href="?confirm=yes" class="btn yes-btn">YES</a>
            <a href="?confirm=no" class="btn no-btn">NO</a>
        </div>
    </div>
</body>
</html>


