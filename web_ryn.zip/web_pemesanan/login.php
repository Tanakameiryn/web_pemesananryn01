<?php 
session_start(); 
include 'koneksi.php';
?>

<!doctype html>
<html lang="en">
  <head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="css/login.css">
    <!-- <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> -->


    <title>Halaman Login</title>
    <style>
    body {

      font-family: 'Poppins', sans-serif;
      background-image: url('images/background/nana.jpg');
      height: 100vh;
      background-size: cover;
      background-position: center;
      background-color: rgba(255, 255, 255, 0.9); 
      opacity: 0.9;

      .card {
            background-color: rgba(255, 255, 255, 0.95); 
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 400px;
            height: 200px;
            text-align: center;
        }
        .btn-container {
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            cursor: pointer;
            width: 120px;
            height: 40px;
            margin-top: 10px; 
            margin-bottom: 10px;
            margin-right: 10px; 
            margin-left: 10px; 
        }


    }
    
  </style>
  </head>
  <body>
  <!-- Form Login -->

    <div class="container">

      <!-- Menampilkan pesan berhasil login -->
      <?php if(isset($_SESSION['login_status']) && $_SESSION['login_status'] === 'success'): ?>
        <div class="alert alert-success" role="alert">
          <?php echo $_SESSION['login_message']; ?>
        </div>
      <?php endif; ?>

      <!-- Menampilkan pesan gagal login -->
      <?php if(isset($_SESSION['login_status']) && $_SESSION['login_status'] === 'error'): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo $_SESSION['login_message']; ?>
        </div>
      <?php endif; ?>
      <h4 class="text-center"; style="color: white;",>FORM LOGIN</h4>
      <hr>
      <form method="POST" action="">
        <div class="form-group">
          <label style="color: white;",for="exampleInputEmail1">Username</label>
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text"><i class="fas fa-user"></i></div>
              </div>
              <input type="text" class="form-control" placeholder="Masukkan Username" name="username">
            </div>
        </div>
        <div class="form-group">
          <label style="color: white;", for="exampleInputPassword1">Password</label>
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text"><i class="fas fa-unlock-alt"></i></div>
              </div>
              <input type="password" class="form-control" placeholder="Masukkan Password" name="password">
          </div>
        </div>
        <div class="mb-3" >
          <small style="color: white;">Belum Punya Akun ? Buat Akun Anda <a href="register.php" class="text-primary">Click Here</a></small>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">LOGIN</button>
        <button type="reset" name="reset" class="btn btn-danger">RESET</button>
      </form>
  <!-- Akhir Form Login -->

  <!-- Eksekusi Form Login -->
      <?php 
        if(isset($_POST['submit'])) {
          $user = $_POST['username'];
          $password = $_POST['password'];

          // Query untuk memilih tabel
          $cek_data = mysqli_query($koneksi, "SELECT * FROM user WHERE username = '$user' AND password = '$password'");
          $hasil = mysqli_fetch_array($cek_data);
          $status = $hasil['status'];
          $login_user = $hasil['username'];
          $row = mysqli_num_rows($cek_data);

          // Pengecekan Kondisi Login Berhasil/Tidak
            if ($row > 0) {
          $_SESSION['login_status'] = 'success'; // Login berhasil
          $_SESSION['login_message'] = 'Login berhasil. Selamat datang, ' . $login_user . '!';
          $_SESSION['login_user'] = $login_user;

          if ($status == 'admin') {
            header('location: admin.php');
          } elseif ($status == 'user') {
            header('location: user.php'); 
          }
        } else {
          $_SESSION['login_status'] = 'error'; // Login gagal
          $_SESSION['login_message'] = 'Login gagal. Username atau password salah.';
          header("location: login.php");
        }
      }

    ?>
    </div>
  <!-- Akhir Eksekusi Form Login -->




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.js"></script>
  </body>
</html>